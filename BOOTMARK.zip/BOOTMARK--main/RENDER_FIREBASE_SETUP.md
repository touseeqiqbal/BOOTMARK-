# Firebase Service Account Setup for Render

## Quick Setup

### Step 1: Copy the Environment Variable Value

Copy this **entire single line** (it's all one line, no breaks) and paste it as the value for `FIREBASE_SERVICE_ACCOUNT` in Render:

```
{"type":"service_account","project_id":"bootmarkapp","private_key_id":"771025f99bfb54508fb3bda8288402d8b54f9082","private_key":"-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDGPzNpULhY8jo7\nrK6g3QM/mpDxdRk3yYuipNLNvGDMlFObpQwUlE0sF39+XhQD8U5y3NnzU3dTzh2h\ncb7VzSmr5nUa1y/uZE8Yiaosk9ZtSCqQw6rcAgaBW7RKqXviJ1KpPN5vCBW+m4RE\nIl+WWZZB/aG/drNGqpEQQhtojDYRIAD57/LUX8MqUeOMli/qlsCfJDYaWBB1gqXw\n7kBE5+jyb9FJ0d2A/ot4xm5STuQVUrzW8gKwojfQYKqEZ9U5bojWtfznApL1jPb5\noktM6Bs5cBWTJrDXGJeNVfC49I2kN2ulwlN+v2QIlVtgy558BVHctfukWSLhLmvO\nroFYo4jdAgMBAAECggEAD0Ue+KW3DWLbCW2rpchgT63gLDkQ0DM+BjEb66zu59Mk\n/YAhBhTGPPcyYtFsSUF1AXPxdcSgFFxz+9N/F4jOBOejbYXVs08WqJUx/m0EvzYn\n0S7BImEljyE5KecUG79bpp2BpJvC0QO5lGXxZutPn5Wht9W0yWSp986fvdXO9FKX\n+mBiswL5eZ2I3YXGKMfXL9uQmnqWf3GdIwMTgLSsVLxRT2n08aKJsmqoZFIAawoY\n1xL+eBNoJnBfUduWttC+Sd/kvbba5M6WvRMr1WIvicqN7dzeI+PqVZrLPX8WW9c1\nUn1cUCfcDbGHwLnUOtiFBQgdyTL/oGD4Xbrynv8+IQKBgQDv/so/detrw/LrNTuf\nGWLYrQaX7RUTSKk6jqd2NFJ7fa6XtIqmBkQxqghJpw6mf+4K0zMiKjX/qMBoymm5\njhdYyoSZk60nUwEwM096KU7LuLlVvMsKW1UfKhlkCef1lQN9pLRI7+obq5co0MQC\nDHEF1zImVFtV9wi+X6yJOoh2JwKBgQDTd64qeVlWWw+7VJU0y5/TRSVNiml7Pxmx\nvfSBqE78MV/0bIq/nT05gXAa+91p9JtE0g4dOaY5Rz6YbzICZMZ/bt8Zm8XFHC6w\nrkpARi8sATdfQiI+LcOPb42l0qIajEiPy12exCyzl/FYLcTS+A+jX1Ixvx1nUSqC\nFs01r6jPWwKBgQDt+F7i/jIp8Wp1/5rW730sDKV1EAjNzka/YaR7ePYwrTbqBoNU\njPIhrM/6+EN2pXOMGE+jmOdiUho3zj13WIWd7XH+NoiDbbLH8JjmMP+I0eo0MbfC\n1T1aYYw7vfbbdJ65fw+lIv+n4EVKm3c/8MZBXFjF2O+YFhP9cTDMAdY+EQKBgQCu\nyVhKwRxndULuir388mV7QcbQbZw8A27ga+qiFJScfM8b/287a+MEGgmoNA/RmR2R\nZ7HE1DahV1LUuevy8IrlH6YFy6xO/LlWzeiPcbNhwuuar9YP4NGoSAMjUZMtMFB1\nkhkitnFgTDFuuf3ahrCeT5Znidjq4bqp5eDeBAAaywKBgDkQI7Ay62Pq33mdsg2u\nwMy9tvvPWEFlD+QsqXugX8g4u5QxRcg8HQDecRI9iOqtwKm4VRgMCKCXCpW24t9l\nxOLZXMhwj/FMfus9kbyDWoBcyKvH9OIhvcdSf8V8LfRdMXiCdUJ4kt2oKo3ZLDlS\n0qNyW0WmRB7CLjRQNMjGLcdX\n-----END PRIVATE KEY-----\n","client_email":"firebase-adminsdk-fbsvc@bootmarkapp.iam.gserviceaccount.com","client_id":"115904323052202304003","auth_uri":"https://accounts.google.com/o/oauth2/auth","token_uri":"https://oauth2.googleapis.com/token","auth_provider_x509_cert_url":"https://www.googleapis.com/oauth2/v1/certs","client_x509_cert_url":"https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-fbsvc%40bootmarkapp.iam.gserviceaccount.com","universe_domain":"googleapis.com"}
```

**⚠️ Important:** This is ONE continuous line. Make sure you copy the entire string without any line breaks.

## Step-by-Step Instructions

1. **Go to Render Dashboard**
   - Navigate to your service
   - Click on "Environment" tab

2. **Add Environment Variable**
   - Click "Add Environment Variable"
   - Key: `FIREBASE_SERVICE_ACCOUNT`
   - Value: Paste the entire JSON string above (single line, no line breaks)

3. **Save and Redeploy**
   - Click "Save Changes"
   - Render will automatically redeploy your service

## Verification

After deployment, check your logs. You should see:
```
✅ Firebase Admin initialized from FIREBASE_SERVICE_ACCOUNT environment variable
   Project ID: bootmarkapp
```

If you see errors, double-check:
- The entire JSON string is on one line
- No extra spaces or line breaks
- All quotes are properly escaped

## Alternative: Using the Script

If you prefer, you can also use the provided script:

```bash
node scripts/prepare-firestore-env.js
```

Then copy the output and paste it into Render.

---

## ⚠️ Important: Frontend Authentication Also Required

**The `FIREBASE_SERVICE_ACCOUNT` works for BOTH Firestore AND Authentication Admin API on the backend.**

However, your **frontend also needs separate Firebase configuration** for user login/registration.

### You need to set these additional variables in Render:

```
VITE_FIREBASE_API_KEY=your-api-key
VITE_FIREBASE_AUTH_DOMAIN=bootmarkapp.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=bootmarkapp
VITE_FIREBASE_STORAGE_BUCKET=bootmarkapp.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=your-sender-id
VITE_FIREBASE_APP_ID=your-app-id
```

**Where to find these:**
1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Select project: **bootmarkapp**
3. Click ⚙️ → **Project settings**
4. Scroll to **Your apps** → Copy `firebaseConfig` values

See `docs/FIREBASE_RENDER_SETUP.md` for complete setup instructions.

import{j as e}from"./vendor-forms-B0IjejrF.js";import{r as l}from"./vendor-react-CNGCEqyP.js";import{a as R}from"./index-Ci1fHsjI.js";import{M as m,X as I,A as q,l as B,i as L}from"./vendor-ui-wdn1VXU5.js";function X({form:s,onClose:d,onSuccess:g}){const[b,E]=l.useState(""),[x,F]=l.useState(`Please fill out: ${(s==null?void 0:s.title)||"Form"}`),[A,O]=l.useState(""),[n,h]=l.useState(!1),[y,i]=l.useState(""),[r,f]=l.useState(!1),c=s!=null&&s.shareKey?`${window.location.origin}/share/${s.shareKey}`:"",M=`Hello,

I'd like to invite you to fill out the following form:

${(s==null?void 0:s.title)||"Form"}

Please click the link below to access the form:
${c}

${s!=null&&s.description?`
Description:
${s.description}
`:""}

Thank you for your time!

Best regards`,[p,z]=l.useState(M),T=async a=>{var v,S,k,N,$,w;a.preventDefault(),i(""),f(!1);const u=b.split(",").map(t=>t.trim()).filter(t=>t.length>0);if(u.length===0){i("Please enter at least one email address");return}const P=/^[^\s@]+@[^\s@]+\.[^\s@]+$/,j=u.filter(t=>!P.test(t));if(j.length>0){i(`Invalid email addresses: ${j.join(", ")}`);return}if(!x.trim()){i("Please enter a subject");return}if(!p.trim()){i("Please enter a message");return}h(!0);try{const t=p.replace(/\n/g,"<br>").replace(/https?:\/\/[^\s]+/g,'<a href="$&" style="color: #4f46e5; text-decoration: underline;">$&</a>'),o=`
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <div style="background-color: #f9fafb; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
            <h2 style="color: #4f46e5; margin-top: 0;">${(s==null?void 0:s.title)||"Form"}</h2>
            ${s!=null&&s.description?`<p style="color: #6b7280;">${s.description}</p>`:""}
          </div>
          <div style="color: #374151; line-height: 1.6;">
            ${t}
          </div>
          <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e5e7eb;">
            <a href="${c}" 
               style="background-color: #4f46e5; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block; font-weight: 600;">
              Open Form
            </a>
          </div>
          <p style="color: #9ca3af; font-size: 12px; margin-top: 20px;">
            This form was sent from BOOTMARK. If you have any questions, please contact the sender.
          </p>
        </div>
      `,C=await R.post("/auth/account/send-email",{to:u,subject:x.trim(),html:o,text:p});(v=C.data)!=null&&v.success?(f(!0),setTimeout(()=>{g&&g(),d&&d()},2e3)):i(((S=C.data)==null?void 0:S.error)||"Failed to send email")}catch(t){console.error("Send email error:",t);let o=((N=(k=t.response)==null?void 0:k.data)==null?void 0:N.error)||((w=($=t.response)==null?void 0:$.data)==null?void 0:w.message)||t.message||"Failed to send email";(o.includes("SMTP")||o.includes("email service not configured"))&&(o="Email service is not configured. Please configure SMTP settings in Account Settings, or contact your administrator to set up default SMTP configuration."),i(o)}finally{h(!1)}};return e.jsx("div",{className:"modal-overlay",onClick:d,children:e.jsxs("div",{className:"modal-content",onClick:a=>a.stopPropagation(),style:{maxWidth:"600px",width:"90%"},children:[e.jsxs("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"20px"},children:[e.jsxs("h2",{style:{margin:0,display:"flex",alignItems:"center",gap:"8px"},children:[e.jsx(m,{size:24}),"Send Form for Entries"]}),e.jsx("button",{className:"icon-btn",onClick:d,style:{border:"none",background:"transparent",cursor:"pointer"},children:e.jsx(I,{size:20})})]}),y&&e.jsxs("div",{style:{padding:"12px",backgroundColor:"#fef2f2",border:"1px solid #fca5a5",borderRadius:"6px",marginBottom:"16px",display:"flex",alignItems:"center",gap:"8px",color:"#991b1b"},children:[e.jsx(q,{size:18}),e.jsx("span",{children:y})]}),r&&e.jsxs("div",{style:{padding:"12px",backgroundColor:"#f0fdf4",border:"1px solid #86efac",borderRadius:"6px",marginBottom:"16px",display:"flex",alignItems:"center",gap:"8px",color:"#166534"},children:[e.jsx(m,{size:18}),e.jsx("span",{children:"Email sent successfully!"})]}),e.jsxs("form",{onSubmit:T,children:[e.jsxs("div",{className:"form-group",children:[e.jsxs("label",{children:["Recipients ",e.jsx("span",{className:"required",children:"*"})]}),e.jsx("input",{type:"text",className:"input",value:b,onChange:a=>E(a.target.value),placeholder:"email1@example.com, email2@example.com",required:!0,disabled:n||r}),e.jsx("small",{style:{color:"#6b7280",marginTop:"4px",display:"block"},children:"Enter email addresses separated by commas for multiple recipients"})]}),e.jsxs("div",{className:"form-group",children:[e.jsxs("label",{children:["Subject ",e.jsx("span",{className:"required",children:"*"})]}),e.jsx("input",{type:"text",className:"input",value:x,onChange:a=>F(a.target.value),placeholder:"Email subject",required:!0,disabled:n||r})]}),e.jsxs("div",{className:"form-group",children:[e.jsxs("label",{children:["Message ",e.jsx("span",{className:"required",children:"*"})]}),e.jsx("textarea",{className:"input",value:p,onChange:a=>z(a.target.value),placeholder:"Email message",rows:8,required:!0,disabled:n||r,style:{fontFamily:"monospace",fontSize:"14px"}}),e.jsx("small",{style:{color:"#6b7280",marginTop:"4px",display:"block"},children:"The form link will be automatically included in the email. You can customize the message above."})]}),c&&e.jsxs("div",{style:{padding:"12px",backgroundColor:"#f9fafb",border:"1px solid #e5e7eb",borderRadius:"6px",marginBottom:"16px"},children:[e.jsx("label",{style:{fontSize:"12px",color:"#6b7280",display:"block",marginBottom:"4px"},children:"Form Link (will be included in email):"}),e.jsxs("div",{style:{display:"flex",gap:"8px",alignItems:"center"},children:[e.jsx("input",{type:"text",value:c,readOnly:!0,style:{flex:1,padding:"8px",border:"1px solid #d1d5db",borderRadius:"4px",fontSize:"12px",backgroundColor:"#fff"}}),e.jsx("button",{type:"button",className:"btn btn-secondary btn-sm",onClick:()=>{navigator.clipboard.writeText(c),alert("Link copied to clipboard!")},children:"Copy"})]})]}),e.jsxs("div",{style:{display:"flex",gap:"12px",justifyContent:"flex-end",marginTop:"20px"},children:[e.jsx("button",{type:"button",className:"btn btn-secondary",onClick:d,disabled:n,children:"Cancel"}),e.jsx("button",{type:"submit",className:"btn btn-primary",disabled:n||r,children:n?e.jsxs(e.Fragment,{children:[e.jsx(B,{size:16,className:"spinner"}),"Sending..."]}):r?e.jsxs(e.Fragment,{children:[e.jsx(m,{size:16}),"Sent!"]}):e.jsxs(e.Fragment,{children:[e.jsx(L,{size:16}),"Send Email"]})})]})]})]})})}export{X as S};

import{j as e}from"./vendor-forms-B0IjejrF.js";import{r as m,u as J}from"./vendor-react-CNGCEqyP.js";import{a as S,l as K}from"./index-Ci1fHsjI.js";import{d as X,e as Z}from"./excelExport-CA0G10mZ.js";import{ar as ee,P as I,q as te,a as W,e as D,at as ne,au as se,a4 as ie,D as ae,V as re,F as T,K as oe,av as k,ae as Y,y as V,i as le,_ as de,A as ce,Z as pe,h as ue}from"./vendor-ui-wdn1VXU5.js";import"./xlsx-CKN5doRT.js";const xe={serviceAgreement:{id:"service-agreement",name:"Service Agreement",description:"Ongoing service contracts with recurring deliverables",icon:"🔧",color:"#3b82f6",defaultDuration:12,billingFrequency:"monthly",autoRenewal:!0,fields:{serviceScope:!0,deliverables:!0,performanceMetrics:!0,paymentSchedule:!0,cancellationTerms:!0},terms:`SERVICE AGREEMENT

This Service Agreement ("Agreement") is entered into as of [START_DATE] between [BUSINESS_NAME] ("Service Provider") and [CLIENT_NAME] ("Client").

1. SERVICES
The Service Provider agrees to provide the following services:
[SERVICE_SCOPE]

2. DELIVERABLES
[DELIVERABLES]

3. TERM
This Agreement shall commence on [START_DATE] and continue for [DURATION] months, ending on [END_DATE].

4. PAYMENT
Total Contract Value: $[AMOUNT]
Payment Schedule: [BILLING_FREQUENCY]
[PAYMENT_SCHEDULE]

5. PERFORMANCE METRICS
[PERFORMANCE_METRICS]

6. TERMINATION
Either party may terminate this Agreement with [CANCELLATION_NOTICE] days written notice.
[CANCELLATION_TERMS]

7. AUTO-RENEWAL
[AUTO_RENEWAL_CLAUSE]

8. CONFIDENTIALITY
Both parties agree to maintain confidentiality of proprietary information.

9. LIMITATION OF LIABILITY
Service Provider's liability shall not exceed the total contract value.

10. GOVERNING LAW
This Agreement shall be governed by the laws of [STATE/COUNTRY].

SIGNATURES:
Service Provider: _____________________ Date: _______
Client: _____________________ Date: _______`},maintenanceContract:{id:"maintenance-contract",name:"Maintenance Contract",description:"Regular maintenance and support agreements",icon:"🛠️",color:"#10b981",defaultDuration:12,billingFrequency:"monthly",autoRenewal:!0,fields:{serviceScope:!0,responseTime:!0,coverageHours:!0,paymentSchedule:!0},terms:`MAINTENANCE CONTRACT

This Maintenance Contract ("Contract") is entered into as of [START_DATE] between [BUSINESS_NAME] ("Provider") and [CLIENT_NAME] ("Client").

1. MAINTENANCE SERVICES
Provider agrees to provide the following maintenance services:
[SERVICE_SCOPE]

2. RESPONSE TIME
- Emergency Issues: [EMERGENCY_RESPONSE] hours
- Standard Issues: [STANDARD_RESPONSE] hours
- Routine Maintenance: [ROUTINE_SCHEDULE]

3. COVERAGE
Service Hours: [COVERAGE_HOURS]
Coverage Days: [COVERAGE_DAYS]

4. TERM AND RENEWAL
Contract Period: [START_DATE] to [END_DATE]
Auto-Renewal: [AUTO_RENEWAL_CLAUSE]

5. FEES
Annual Fee: $[AMOUNT]
Payment Terms: [BILLING_FREQUENCY]
[PAYMENT_SCHEDULE]

6. EXCLUSIONS
The following are not covered under this contract:
- Damage caused by misuse or negligence
- Third-party equipment or software
- Services outside normal business hours (unless emergency)

7. TERMINATION
[CANCELLATION_TERMS]

SIGNATURES:
Provider: _____________________ Date: _______
Client: _____________________ Date: _______`},projectContract:{id:"project-contract",name:"Project Contract",description:"One-time project-based contracts with milestones",icon:"📋",color:"#8b5cf6",defaultDuration:6,billingFrequency:"milestone",autoRenewal:!1,fields:{projectScope:!0,deliverables:!0,milestones:!0,paymentSchedule:!0,changeOrders:!0},terms:`PROJECT CONTRACT

This Project Contract ("Contract") is entered into as of [START_DATE] between [BUSINESS_NAME] ("Contractor") and [CLIENT_NAME] ("Client").

1. PROJECT SCOPE
[PROJECT_SCOPE]

2. DELIVERABLES
[DELIVERABLES]

3. PROJECT TIMELINE
Start Date: [START_DATE]
Completion Date: [END_DATE]

MILESTONES:
[MILESTONES]

4. PAYMENT
Total Project Cost: $[AMOUNT]
Payment Schedule:
[PAYMENT_SCHEDULE]

5. CHANGE ORDERS
Any changes to the project scope must be documented in writing and may result in adjusted timeline and costs.

6. ACCEPTANCE CRITERIA
[ACCEPTANCE_CRITERIA]

7. WARRANTIES
Contractor warrants that all work will be performed in a professional manner and will be free from defects for [WARRANTY_PERIOD] days.

8. INTELLECTUAL PROPERTY
[IP_TERMS]

SIGNATURES:
Contractor: _____________________ Date: _______
Client: _____________________ Date: _______`},retainerAgreement:{id:"retainer-agreement",name:"Retainer Agreement",description:"Monthly retainer contracts with allocated hours",icon:"⏰",color:"#f59e0b",defaultDuration:12,billingFrequency:"monthly",autoRenewal:!0,fields:{monthlyHours:!0,hourlyRate:!0,rolloverPolicy:!0,serviceScope:!0},terms:`RETAINER AGREEMENT

This Retainer Agreement ("Agreement") is entered into as of [START_DATE] between [BUSINESS_NAME] ("Service Provider") and [CLIENT_NAME] ("Client").

1. RETAINER SERVICES
Service Provider agrees to provide [MONTHLY_HOURS] hours of service per month for the following:
[SERVICE_SCOPE]

2. FEES
Monthly Retainer: $[MONTHLY_AMOUNT]
Hourly Rate: $[HOURLY_RATE]
Total Annual Value: $[AMOUNT]

3. HOURS ALLOCATION
- Monthly Allocation: [MONTHLY_HOURS] hours
- Rollover Policy: [ROLLOVER_POLICY]
- Additional Hours: Billed at $[HOURLY_RATE]/hour

4. TERM
This Agreement is effective from [START_DATE] to [END_DATE] and will automatically renew for successive [RENEWAL_PERIOD] periods unless terminated.

5. PAYMENT
Payment is due on the [PAYMENT_DAY] of each month, regardless of hours used.

6. TERMINATION
Either party may terminate with [CANCELLATION_NOTICE] days written notice.

7. UNUSED HOURS
[UNUSED_HOURS_POLICY]

SIGNATURES:
Service Provider: _____________________ Date: _______
Client: _____________________ Date: _______`},subscriptionContract:{id:"subscription-contract",name:"Subscription Contract",description:"Recurring subscription service agreements",icon:"🔄",color:"#ef4444",defaultDuration:12,billingFrequency:"monthly",autoRenewal:!0,fields:{subscriptionTier:!0,features:!0,userLimits:!0,supportLevel:!0},terms:`SUBSCRIPTION SERVICE AGREEMENT

This Subscription Agreement ("Agreement") is entered into as of [START_DATE] between [BUSINESS_NAME] ("Provider") and [CLIENT_NAME] ("Subscriber").

1. SUBSCRIPTION SERVICES
Subscription Tier: [SUBSCRIPTION_TIER]
Features Included:
[FEATURES]

2. SUBSCRIPTION TERM
Start Date: [START_DATE]
Billing Cycle: [BILLING_FREQUENCY]
Auto-Renewal: Yes

3. FEES
Subscription Fee: $[MONTHLY_AMOUNT]/[BILLING_FREQUENCY]
Annual Total: $[AMOUNT]

4. USER LIMITS
[USER_LIMITS]

5. SUPPORT
Support Level: [SUPPORT_LEVEL]
Response Time: [RESPONSE_TIME]

6. SERVICE LEVEL AGREEMENT
Uptime Guarantee: [UPTIME_PERCENTAGE]%
Credits for Downtime: [SLA_CREDITS]

7. DATA AND PRIVACY
[DATA_PRIVACY_TERMS]

8. CANCELLATION
Subscriber may cancel at any time with [CANCELLATION_NOTICE] days notice. No refunds for partial periods.

9. MODIFICATIONS
Provider reserves the right to modify features and pricing with [NOTICE_PERIOD] days notice.

SIGNATURES:
Provider: _____________________ Date: _______
Subscriber: _____________________ Date: _______`},customTemplate:{id:"custom-template",name:"Custom Template",description:"Create your own custom contract template",icon:"✏️",color:"#6b7280",defaultDuration:12,billingFrequency:"monthly",autoRenewal:!1,fields:{customFields:!0},terms:`CUSTOM CONTRACT

This Contract is entered into as of [START_DATE] between [BUSINESS_NAME] and [CLIENT_NAME].

[CUSTOM_TERMS]

SIGNATURES:
Party 1: _____________________ Date: _______
Party 2: _____________________ Date: _______`}};function j(){return Object.values(xe)}function me({onSelect:b,selectedTemplate:h}){var g;const p=j();return e.jsxs("div",{style:{marginBottom:"24px"},children:[e.jsx("label",{style:{display:"block",marginBottom:"12px",fontWeight:"600",fontSize:"14px"},children:"Select Contract Template"}),e.jsx("div",{style:{display:"grid",gridTemplateColumns:"repeat(auto-fit, minmax(200px, 1fr))",gap:"12px"},children:p.map(l=>{const _=h===l.id;return e.jsxs("div",{onClick:()=>b(l),style:{padding:"16px",border:`2px solid ${_?l.color:"#e5e7eb"}`,borderRadius:"12px",cursor:"pointer",transition:"all 0.2s",background:_?`${l.color}10`:"white",position:"relative"},onMouseEnter:x=>{_||(x.currentTarget.style.borderColor=l.color,x.currentTarget.style.transform="translateY(-2px)")},onMouseLeave:x=>{_||(x.currentTarget.style.borderColor="#e5e7eb",x.currentTarget.style.transform="translateY(0)")},children:[_&&e.jsx("div",{style:{position:"absolute",top:"8px",right:"8px",background:l.color,color:"white",borderRadius:"50%",width:"24px",height:"24px",display:"flex",alignItems:"center",justifyContent:"center"},children:e.jsx(ee,{size:16})}),e.jsx("div",{style:{fontSize:"32px",marginBottom:"8px",textAlign:"center"},children:l.icon}),e.jsx("h4",{style:{margin:"0 0 4px 0",fontSize:"14px",fontWeight:"600",color:"#111827",textAlign:"center"},children:l.name}),e.jsx("p",{style:{margin:0,fontSize:"11px",color:"#6b7280",textAlign:"center",lineHeight:"1.4"},children:l.description}),e.jsxs("div",{style:{marginTop:"12px",paddingTop:"12px",borderTop:"1px solid #e5e7eb",display:"flex",justifyContent:"space-between",fontSize:"10px",color:"#9ca3af"},children:[e.jsxs("span",{children:[l.defaultDuration,"mo"]}),e.jsx("span",{children:l.billingFrequency})]})]},l.id)})}),h&&e.jsxs("div",{style:{marginTop:"16px",padding:"12px 16px",background:"#f0fdf4",border:"1px solid #86efac",borderRadius:"8px",fontSize:"13px",color:"#166534"},children:[e.jsx("strong",{children:"Selected:"})," ",(g=p.find(l=>l.id===h))==null?void 0:g.name]})]})}function _e({schedule:b,onChange:h}){const[p,g]=m.useState(b||[{id:1,description:"",amount:"",dueDate:"",status:"pending"}]),l=()=>{const d={id:Date.now(),description:"",amount:"",dueDate:"",status:"pending"},r=[...p,d];g(r),h(r)},_=d=>{const r=p.filter(u=>u.id!==d);g(r),h(r)},x=(d,r,u)=>{const f=p.map(E=>E.id===d?{...E,[r]:u}:E);g(f),h(f)},C=p.reduce((d,r)=>d+(parseFloat(r.amount)||0),0);return e.jsxs("div",{style:{marginBottom:"24px"},children:[e.jsxs("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"12px"},children:[e.jsx("label",{style:{fontWeight:"600",fontSize:"14px"},children:"Payment Schedule"}),e.jsxs("button",{type:"button",onClick:l,className:"btn btn-sm btn-secondary",style:{padding:"4px 12px",fontSize:"12px"},children:[e.jsx(I,{size:14})," Add Milestone"]})]}),e.jsx("div",{style:{display:"flex",flexDirection:"column",gap:"12px"},children:p.map((d,r)=>e.jsxs("div",{style:{padding:"16px",background:"#f9fafb",border:"1px solid #e5e7eb",borderRadius:"8px",display:"grid",gridTemplateColumns:"2fr 1fr 1fr auto",gap:"12px",alignItems:"end"},children:[e.jsxs("div",{children:[e.jsxs("label",{style:{display:"block",fontSize:"11px",fontWeight:"500",marginBottom:"4px",color:"#6b7280"},children:["Description / Milestone ",r+1]}),e.jsx("input",{type:"text",value:d.description,onChange:u=>x(d.id,"description",u.target.value),placeholder:"e.g., Initial deposit, Project completion",className:"form-control",style:{fontSize:"13px"}})]}),e.jsxs("div",{children:[e.jsxs("label",{style:{display:"block",fontSize:"11px",fontWeight:"500",marginBottom:"4px",color:"#6b7280"},children:[e.jsx(te,{size:12,style:{display:"inline",marginRight:"2px"}}),"Amount"]}),e.jsx("input",{type:"number",step:"0.01",value:d.amount,onChange:u=>x(d.id,"amount",u.target.value),placeholder:"0.00",className:"form-control",style:{fontSize:"13px"}})]}),e.jsxs("div",{children:[e.jsxs("label",{style:{display:"block",fontSize:"11px",fontWeight:"500",marginBottom:"4px",color:"#6b7280"},children:[e.jsx(W,{size:12,style:{display:"inline",marginRight:"2px"}}),"Due Date"]}),e.jsx("input",{type:"date",value:d.dueDate,onChange:u=>x(d.id,"dueDate",u.target.value),className:"form-control",style:{fontSize:"13px"}})]}),p.length>1&&e.jsx("button",{type:"button",onClick:()=>_(d.id),className:"btn btn-icon",style:{marginBottom:"2px"},title:"Remove milestone",children:e.jsx(D,{size:16,color:"#ef4444"})})]},d.id))}),p.length>0&&e.jsxs("div",{style:{marginTop:"12px",padding:"12px 16px",background:"#eff6ff",border:"1px solid #bfdbfe",borderRadius:"8px",display:"flex",justifyContent:"space-between",alignItems:"center"},children:[e.jsx("span",{style:{fontSize:"13px",color:"#1e40af",fontWeight:"500"},children:"Total Payment Schedule"}),e.jsxs("span",{style:{fontSize:"18px",fontWeight:"700",color:"#1e3a8a",fontFamily:"monospace"},children:["$",C.toFixed(2)]})]}),e.jsx("p",{style:{marginTop:"8px",fontSize:"11px",color:"#6b7280",margin:"8px 0 0 0"},children:"💡 Tip: Break down the total contract value into payment milestones. Each milestone can be linked to specific deliverables."})]})}function Se(){const[b,h]=m.useState([]),[p,g]=m.useState([]),[l,_]=m.useState(!0),[x,C]=m.useState(""),[d,r]=m.useState(!1),[u,f]=m.useState(null),[E,w]=m.useState("grid"),[v,$]=m.useState(!1),[y,L]=m.useState({status:"all",type:"all",dateRange:"all"}),[n,o]=m.useState({title:"",clientId:"",startDate:"",endDate:"",status:"draft",amount:"",description:"",terms:"",templateId:"",billingFrequency:"monthly",autoRenewal:!1,renewalNoticePeriod:30,serviceScope:"",deliverables:"",paymentSchedule:[],cancellationTerms:"",attachments:[]}),O=J();m.useEffect(()=>{N(),q()},[]);const N=async()=>{try{_(!0);const t=await S.get("/contracts");h(t.data||[])}catch(t){console.error("Failed to fetch contracts",t)}finally{_(!1)}},q=async()=>{try{const t=await S.get("/customers");g(t.data||[])}catch(t){console.error("Failed to fetch clients",t)}},G=t=>{o(s=>({...s,templateId:t.id,billingFrequency:t.billingFrequency,autoRenewal:t.autoRenewal,terms:t.terms}))},M=t=>{var s,c;f(t),o({title:t.title,clientId:t.clientId,startDate:((s=t.startDate)==null?void 0:s.split("T")[0])||"",endDate:((c=t.endDate)==null?void 0:c.split("T")[0])||"",status:t.status||"draft",amount:t.amount,description:t.description||"",terms:t.terms||"",templateId:t.templateId||"",billingFrequency:t.billingFrequency||"monthly",autoRenewal:t.autoRenewal||!1,renewalNoticePeriod:t.renewalNoticePeriod||30,serviceScope:t.serviceScope||"",deliverables:t.deliverables||"",paymentSchedule:t.paymentSchedule||[],cancellationTerms:t.cancellationTerms||"",attachments:t.attachments||[]}),r(!0)},P=async t=>{if(confirm("Are you sure you want to delete this contract?"))try{await S.delete(`/contracts/${t}`),N()}catch(s){console.error("Failed to delete contract",s)}},z=async t=>{const s={...t,title:`${t.title} (Copy)`,status:"draft",id:void 0};o(s),f(null),r(!0)},U=async t=>{try{const s=await S.get(`/contracts/${t}/pdf`,{responseType:"blob"}),c=window.URL.createObjectURL(new Blob([s.data])),a=document.createElement("a");a.href=c,a.setAttribute("download",`contract-${t}.pdf`),document.body.appendChild(a),a.click(),a.remove(),window.URL.revokeObjectURL(c)}catch(s){console.error("Failed to download PDF:",s),alert("Failed to download PDF. Please try again.")}},H=async t=>{var s,c;t.preventDefault();try{u?await S.put(`/contracts/${u.id}`,n):await S.post("/contracts",n),r(!1),f(null),A(),N()}catch(a){console.error("Failed to save contract",a),alert("Failed to save contract: "+(((c=(s=a.response)==null?void 0:s.data)==null?void 0:c.error)||a.message))}},A=()=>{o({title:"",clientId:"",startDate:"",endDate:"",status:"draft",amount:"",description:"",terms:"",templateId:"",billingFrequency:"monthly",autoRenewal:!1,renewalNoticePeriod:30,serviceScope:"",deliverables:"",paymentSchedule:[],cancellationTerms:"",attachments:[]})},R=b.filter(t=>{var i;const s=(t.title||"").toLowerCase().includes(x.toLowerCase())||(((i=p.find(Q=>Q.id===t.clientId))==null?void 0:i.name)||"").toLowerCase().includes(x.toLowerCase()),c=y.status==="all"||t.status===y.status,a=y.type==="all"||t.templateId===y.type;return s&&c&&a}),B=t=>{if(!t)return"#3b82f6";switch(t){case"active":return"#10b981";case"draft":return"#6b7280";case"expired":return"#ef4444";case"cancelled":return"#f59e0b";case"pending-signature":return"#8b5cf6";default:return"#3b82f6"}},F=t=>{if(!t)return e.jsx(T,{size:14});switch(t){case"active":return e.jsx(ue,{size:14});case"draft":return e.jsx(pe,{size:14});case"expired":return e.jsx(ce,{size:14});case"cancelled":return e.jsx(de,{size:14});case"pending-signature":return e.jsx(le,{size:14});default:return e.jsx(T,{size:14})}};return e.jsxs("div",{className:"dashboard",children:[e.jsx("header",{className:"dashboard-header",children:e.jsx("div",{className:"container",children:e.jsxs("div",{className:"header-content",children:[e.jsxs("div",{className:"dashboard-brand",children:[e.jsx("img",{src:K,alt:"BOOTMARK Logo",className:"brand-logo"}),e.jsxs("div",{className:"brand-text",children:[e.jsx("h1",{className:"brand-title",children:"Contracts Management"}),e.jsxs("span",{className:"brand-subtitle",children:[b.length," total contracts"]})]})]}),e.jsxs("div",{className:"header-actions",children:[e.jsxs("div",{style:{display:"flex",gap:"8px",alignItems:"center",marginRight:"12px"},children:[e.jsx("button",{className:`btn btn-icon ${E==="grid"?"btn-primary":"btn-secondary"}`,onClick:()=>w("grid"),title:"Grid View",children:e.jsx(ne,{size:18})}),e.jsx("button",{className:`btn btn-icon ${E==="list"?"btn-primary":"btn-secondary"}`,onClick:()=>w("list"),title:"List View",children:e.jsx(se,{size:18})})]}),e.jsxs("button",{className:"btn btn-secondary",onClick:()=>$(!v),children:[e.jsx(ie,{size:18})," Filters"]}),e.jsxs("button",{className:"btn btn-secondary",onClick:()=>{const t=X(b,p);Z(t,`contracts-${new Date().toISOString().split("T")[0]}`,"Contracts")},children:[e.jsx(ae,{size:18})," Export"]}),e.jsxs("button",{className:"btn btn-primary",onClick:()=>{f(null),A(),r(!0)},children:[e.jsx(I,{size:18})," New Contract"]})]})]})})}),e.jsxs("div",{className:"container",children:[e.jsxs("div",{style:{marginBottom:"24px"},children:[e.jsxs("div",{style:{position:"relative",marginBottom:v?"16px":"0"},children:[e.jsx(re,{size:20,style:{position:"absolute",left:"12px",top:"50%",transform:"translateY(-50%)",color:"#9ca3af"}}),e.jsx("input",{type:"text",placeholder:"Search contracts by title or client name...",value:x,onChange:t=>C(t.target.value),className:"form-control",style:{width:"100%",paddingLeft:"40px"}})]}),v&&e.jsxs("div",{style:{padding:"16px",background:"#f9fafb",border:"1px solid #e5e7eb",borderRadius:"8px",display:"grid",gridTemplateColumns:"repeat(auto-fit, minmax(200px, 1fr))",gap:"12px"},children:[e.jsxs("div",{children:[e.jsx("label",{style:{display:"block",fontSize:"12px",fontWeight:"500",marginBottom:"4px"},children:"Status"}),e.jsxs("select",{value:y.status,onChange:t=>L({...y,status:t.target.value}),className:"form-control",style:{fontSize:"13px"},children:[e.jsx("option",{value:"all",children:"All Statuses"}),e.jsx("option",{value:"draft",children:"Draft"}),e.jsx("option",{value:"active",children:"Active"}),e.jsx("option",{value:"pending-signature",children:"Pending Signature"}),e.jsx("option",{value:"expired",children:"Expired"}),e.jsx("option",{value:"cancelled",children:"Cancelled"})]})]}),e.jsxs("div",{children:[e.jsx("label",{style:{display:"block",fontSize:"12px",fontWeight:"500",marginBottom:"4px"},children:"Contract Type"}),e.jsxs("select",{value:y.type,onChange:t=>L({...y,type:t.target.value}),className:"form-control",style:{fontSize:"13px"},children:[e.jsx("option",{value:"all",children:"All Types"}),j().map(t=>e.jsx("option",{value:t.id,children:t.name},t.id))]})]})]})]}),l?e.jsx("div",{className:"loading",children:"Loading contracts..."}):R.length===0?e.jsxs("div",{className:"empty-state",style:{textAlign:"center",padding:"60px",background:"white",borderRadius:"12px",border:"1px solid #e5e7eb"},children:[e.jsx(T,{size:48,color:"#d1d5db",style:{marginBottom:"16px"}}),e.jsx("h3",{children:"No contracts found"}),e.jsx("p",{style:{color:"#6b7280"},children:"Create contracts to track customer agreements."}),e.jsxs("button",{className:"btn btn-primary",onClick:()=>{f(null),A(),r(!0)},style:{marginTop:"16px"},children:[e.jsx(I,{size:18})," Create Your First Contract"]})]}):E==="grid"?e.jsx("div",{className:"contracts-grid",style:{display:"grid",gridTemplateColumns:"repeat(auto-fill, minmax(350px, 1fr))",gap:"20px"},children:R.map(t=>{const s=p.find(i=>i.id===t.clientId),c=B(t.status),a=j().find(i=>i.id===t.templateId);return e.jsxs("div",{className:"card",style:{position:"relative",borderLeft:`4px solid ${c}`,cursor:"pointer",transition:"all 0.2s"},onClick:()=>O(`/contracts/${t.id}`),onMouseEnter:i=>{i.currentTarget.style.transform="translateY(-2px)",i.currentTarget.style.boxShadow="0 4px 6px -1px rgba(0, 0, 0, 0.1)"},onMouseLeave:i=>{i.currentTarget.style.transform="translateY(0)",i.currentTarget.style.boxShadow="none"},children:[a&&e.jsx("div",{style:{position:"absolute",top:"12px",right:"12px",fontSize:"24px"},children:a.icon}),e.jsxs("div",{style:{marginBottom:"12px"},children:[e.jsx("h3",{style:{margin:"0 0 4px 0",fontSize:"18px",paddingRight:"40px"},children:t.title||"Untitled Contract"}),e.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"6px",fontSize:"13px",color:"#6b7280"},children:[e.jsx(oe,{size:14}),s?s.name:"Unknown Client"]}),a&&e.jsx("div",{style:{fontSize:"11px",color:"#9ca3af",marginTop:"4px"},children:a.name})]}),e.jsxs("div",{style:{display:"flex",justifyContent:"space-between",marginBottom:"16px",fontSize:"14px"},children:[e.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"6px",fontSize:"12px"},children:[e.jsx(W,{size:14,color:"#6b7280"}),e.jsxs("span",{children:[new Date(t.startDate).toLocaleDateString()," - ",new Date(t.endDate).toLocaleDateString()]})]}),e.jsxs("div",{style:{fontWeight:"600",fontFamily:"monospace"},children:["$",t.amount||"0.00"]})]}),e.jsxs("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center"},children:[e.jsxs("span",{style:{display:"flex",alignItems:"center",gap:"4px",fontSize:"12px",color:c,fontWeight:"500",padding:"2px 8px",borderRadius:"12px",background:`${c}20`},children:[F(t.status),(t.status||"draft").charAt(0).toUpperCase()+(t.status||"draft").slice(1).replace("-"," ")]}),e.jsxs("div",{style:{display:"flex",gap:"4px"},onClick:i=>i.stopPropagation(),children:[e.jsx("button",{className:"btn btn-icon",onClick:()=>U(t.id),title:"Download PDF",children:e.jsx(k,{size:14})}),e.jsx("button",{className:"btn btn-icon",onClick:()=>z(t),title:"Duplicate",children:e.jsx(Y,{size:14})}),e.jsx("button",{className:"btn btn-icon",onClick:()=>M(t),title:"Edit",children:e.jsx(V,{size:14})}),e.jsx("button",{className:"btn btn-icon",onClick:()=>P(t.id),title:"Delete",children:e.jsx(D,{size:14})})]})]})]},t.id)})}):e.jsx("div",{style:{background:"white",borderRadius:"12px",border:"1px solid #e5e7eb",overflow:"hidden"},children:e.jsxs("table",{style:{width:"100%",borderCollapse:"collapse"},children:[e.jsx("thead",{style:{background:"#f9fafb",borderBottom:"1px solid #e5e7eb"},children:e.jsxs("tr",{children:[e.jsx("th",{style:{padding:"12px 16px",textAlign:"left",fontSize:"12px",fontWeight:"600",color:"#6b7280"},children:"Contract"}),e.jsx("th",{style:{padding:"12px 16px",textAlign:"left",fontSize:"12px",fontWeight:"600",color:"#6b7280"},children:"Client"}),e.jsx("th",{style:{padding:"12px 16px",textAlign:"left",fontSize:"12px",fontWeight:"600",color:"#6b7280"},children:"Type"}),e.jsx("th",{style:{padding:"12px 16px",textAlign:"left",fontSize:"12px",fontWeight:"600",color:"#6b7280"},children:"Duration"}),e.jsx("th",{style:{padding:"12px 16px",textAlign:"right",fontSize:"12px",fontWeight:"600",color:"#6b7280"},children:"Value"}),e.jsx("th",{style:{padding:"12px 16px",textAlign:"left",fontSize:"12px",fontWeight:"600",color:"#6b7280"},children:"Status"}),e.jsx("th",{style:{padding:"12px 16px",textAlign:"right",fontSize:"12px",fontWeight:"600",color:"#6b7280"},children:"Actions"})]})}),e.jsx("tbody",{children:R.map(t=>{const s=p.find(i=>i.id===t.clientId),c=B(t.status),a=j().find(i=>i.id===t.templateId);return e.jsxs("tr",{style:{borderBottom:"1px solid #f3f4f6",cursor:"pointer",transition:"background 0.2s"},onClick:()=>O(`/contracts/${t.id}`),onMouseEnter:i=>i.currentTarget.style.background="#f9fafb",onMouseLeave:i=>i.currentTarget.style.background="white",children:[e.jsx("td",{style:{padding:"12px 16px"},children:e.jsx("div",{style:{fontWeight:"500"},children:t.title})}),e.jsx("td",{style:{padding:"12px 16px",fontSize:"14px"},children:(s==null?void 0:s.name)||"Unknown"}),e.jsx("td",{style:{padding:"12px 16px",fontSize:"13px"},children:a?e.jsxs("span",{style:{display:"flex",alignItems:"center",gap:"6px"},children:[e.jsx("span",{children:a.icon}),a.name]}):"-"}),e.jsxs("td",{style:{padding:"12px 16px",fontSize:"13px",color:"#6b7280"},children:[new Date(t.startDate).toLocaleDateString()," - ",new Date(t.endDate).toLocaleDateString()]}),e.jsxs("td",{style:{padding:"12px 16px",textAlign:"right",fontFamily:"monospace",fontWeight:"600"},children:["$",t.amount]}),e.jsx("td",{style:{padding:"12px 16px"},children:e.jsxs("span",{style:{display:"inline-flex",alignItems:"center",gap:"4px",fontSize:"12px",color:c,fontWeight:"500",padding:"2px 8px",borderRadius:"12px",background:`${c}20`},children:[F(t.status),(t.status||"draft").charAt(0).toUpperCase()+(t.status||"draft").slice(1).replace("-"," ")]})}),e.jsx("td",{style:{padding:"12px 16px",textAlign:"right"},onClick:i=>i.stopPropagation(),children:e.jsxs("div",{style:{display:"flex",gap:"4px",justifyContent:"flex-end"},children:[e.jsx("button",{className:"btn btn-icon",onClick:()=>U(t.id),title:"Download PDF",children:e.jsx(k,{size:14})}),e.jsx("button",{className:"btn btn-icon",onClick:()=>z(t),title:"Duplicate",children:e.jsx(Y,{size:14})}),e.jsx("button",{className:"btn btn-icon",onClick:()=>M(t),title:"Edit",children:e.jsx(V,{size:14})}),e.jsx("button",{className:"btn btn-icon",onClick:()=>P(t.id),title:"Delete",children:e.jsx(D,{size:14})})]})})]},t.id)})})]})})]}),d&&e.jsx("div",{className:"modal-overlay",onClick:()=>r(!1),children:e.jsxs("div",{className:"modal-content",onClick:t=>t.stopPropagation(),style:{maxWidth:"900px",maxHeight:"90vh",overflow:"auto"},children:[e.jsx("h2",{children:u?"Edit Contract":"New Contract"}),e.jsxs("form",{onSubmit:H,children:[!u&&e.jsx(me,{onSelect:G,selectedTemplate:n.templateId}),e.jsxs("div",{style:{marginBottom:"24px"},children:[e.jsx("h3",{style:{fontSize:"16px",marginBottom:"16px",paddingBottom:"8px",borderBottom:"2px solid #e5e7eb"},children:"Basic Information"}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{children:"Contract Title *"}),e.jsx("input",{type:"text",placeholder:"e.g. Annual Maintenance Agreement 2024",required:!0,value:n.title,onChange:t=>o({...n,title:t.target.value}),className:"form-control"})]}),e.jsxs("div",{style:{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"16px"},children:[e.jsxs("div",{className:"form-group",children:[e.jsx("label",{children:"Client *"}),e.jsxs("select",{required:!0,value:n.clientId,onChange:t=>o({...n,clientId:t.target.value}),className:"form-control",children:[e.jsx("option",{value:"",children:"Select Client"}),p.map(t=>e.jsx("option",{value:t.id,children:t.name},t.id))]})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{children:"Status"}),e.jsxs("select",{value:n.status,onChange:t=>o({...n,status:t.target.value}),className:"form-control",children:[e.jsx("option",{value:"draft",children:"Draft"}),e.jsx("option",{value:"pending-signature",children:"Pending Signature"}),e.jsx("option",{value:"active",children:"Active"}),e.jsx("option",{value:"expired",children:"Expired"}),e.jsx("option",{value:"cancelled",children:"Cancelled"})]})]})]}),e.jsxs("div",{style:{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:"16px"},children:[e.jsxs("div",{className:"form-group",children:[e.jsx("label",{children:"Start Date *"}),e.jsx("input",{type:"date",required:!0,value:n.startDate,onChange:t=>o({...n,startDate:t.target.value}),className:"form-control"})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{children:"End Date *"}),e.jsx("input",{type:"date",required:!0,value:n.endDate,onChange:t=>o({...n,endDate:t.target.value}),className:"form-control"})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{children:"Total Value ($) *"}),e.jsx("input",{type:"number",step:"0.01",required:!0,value:n.amount,onChange:t=>o({...n,amount:t.target.value}),className:"form-control"})]})]})]}),e.jsxs("div",{style:{marginBottom:"24px"},children:[e.jsx("h3",{style:{fontSize:"16px",marginBottom:"16px",paddingBottom:"8px",borderBottom:"2px solid #e5e7eb"},children:"Payment & Billing"}),e.jsxs("div",{style:{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"16px",marginBottom:"16px"},children:[e.jsxs("div",{className:"form-group",children:[e.jsx("label",{children:"Billing Frequency"}),e.jsxs("select",{value:n.billingFrequency,onChange:t=>o({...n,billingFrequency:t.target.value}),className:"form-control",children:[e.jsx("option",{value:"one-time",children:"One-Time"}),e.jsx("option",{value:"monthly",children:"Monthly"}),e.jsx("option",{value:"quarterly",children:"Quarterly"}),e.jsx("option",{value:"annually",children:"Annually"}),e.jsx("option",{value:"milestone",children:"Milestone-Based"})]})]}),e.jsxs("div",{className:"form-group",children:[e.jsxs("label",{style:{display:"flex",alignItems:"center",gap:"8px"},children:[e.jsx("input",{type:"checkbox",checked:n.autoRenewal,onChange:t=>o({...n,autoRenewal:t.target.checked})}),"Auto-Renewal"]}),n.autoRenewal&&e.jsx("input",{type:"number",placeholder:"Notice period (days)",value:n.renewalNoticePeriod,onChange:t=>o({...n,renewalNoticePeriod:t.target.value}),className:"form-control",style:{marginTop:"8px"}})]})]}),e.jsx(_e,{schedule:n.paymentSchedule,onChange:t=>o({...n,paymentSchedule:t})})]}),e.jsxs("div",{style:{marginBottom:"24px"},children:[e.jsx("h3",{style:{fontSize:"16px",marginBottom:"16px",paddingBottom:"8px",borderBottom:"2px solid #e5e7eb"},children:"Scope & Details"}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{children:"Description"}),e.jsx("textarea",{rows:2,value:n.description,onChange:t=>o({...n,description:t.target.value}),className:"form-control",placeholder:"Brief description of the contract"})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{children:"Service Scope"}),e.jsx("textarea",{rows:3,value:n.serviceScope,onChange:t=>o({...n,serviceScope:t.target.value}),className:"form-control",placeholder:"Detailed scope of services to be provided"})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{children:"Deliverables"}),e.jsx("textarea",{rows:3,value:n.deliverables,onChange:t=>o({...n,deliverables:t.target.value}),className:"form-control",placeholder:"Expected deliverables and outcomes"})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{children:"Cancellation Terms"}),e.jsx("textarea",{rows:2,value:n.cancellationTerms,onChange:t=>o({...n,cancellationTerms:t.target.value}),className:"form-control",placeholder:"Terms and conditions for contract cancellation"})]})]}),e.jsxs("div",{style:{marginBottom:"24px"},children:[e.jsx("h3",{style:{fontSize:"16px",marginBottom:"16px",paddingBottom:"8px",borderBottom:"2px solid #e5e7eb"},children:"Terms & Conditions"}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{children:"Contract Terms"}),e.jsx("textarea",{rows:8,value:n.terms,onChange:t=>o({...n,terms:t.target.value}),className:"form-control",placeholder:"Full terms and conditions (auto-populated from template)",style:{fontFamily:"monospace",fontSize:"12px"}})]})]}),e.jsxs("div",{style:{display:"flex",justifyContent:"flex-end",gap:"8px",marginTop:"24px",paddingTop:"24px",borderTop:"2px solid #e5e7eb"},children:[e.jsx("button",{type:"button",className:"btn btn-secondary",onClick:()=>r(!1),children:"Cancel"}),e.jsxs("button",{type:"submit",className:"btn btn-primary",children:[e.jsx(T,{size:18})," ",u?"Update Contract":"Create Contract"]})]})]})]})})]})}export{Se as default};
